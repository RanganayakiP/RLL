package com.hospital.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospital.dao.DoctorSignUpRepository;
import com.hospital.dao.FeedbackRepository;
import com.hospital.model.Doctor;
import com.hospital.model.Feedback;
@Service
public class FeedbackService {
	@Autowired
	FeedbackRepository feedbackrepository;
	
	public List<Feedback> fetchFeedbacks() {
		List<Feedback> feedbacklist=feedbackrepository.findAll();
		return feedbacklist;
		
	}
	
	public Feedback saveFeedbacks(Feedback feedback) {
		
		return feedbackrepository.save(feedback);
		

}
}