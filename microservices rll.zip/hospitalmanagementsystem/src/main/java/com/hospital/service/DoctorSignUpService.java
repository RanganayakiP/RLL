package com.hospital.service;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospital.dao.DoctorSignUpRepository;
import com.hospital.model.Doctor;
@Service
public class DoctorSignUpService {
	@Autowired
	DoctorSignUpRepository doctorsignupRepository;
	
	public List<Doctor> fetchDoctors() {
		List<Doctor> doctorlist=doctorsignupRepository.findAll();
		return doctorlist;
		
	}
	
	public Doctor saveDoctor(Doctor doctorsignup) {
		
		return doctorsignupRepository.save(doctorsignup);
		
	}
	
	public void updateDoctor(Doctor d) {
		doctorsignupRepository.save(d);	
	
	}
	
	public void deleteDoctor(int d_Id) {
		
		System.out.println("service method called");
		doctorsignupRepository.deleteById(d_Id);
	
	}
	
	  public Doctor getDoctor(int d_Id) { 
	  Optional<Doctor> optional= doctorsignupRepository.findById(d_Id);
	  Doctor d=optional.get();
	  return d;
	  }
	

}
