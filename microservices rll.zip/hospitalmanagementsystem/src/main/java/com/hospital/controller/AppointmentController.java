package com.hospital.controller;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hospital.dao.AppointmentRepository;

import com.hospital.exception.ResourceNotFoundException;
import com.hospital.model.Appointment;



@RestController
public class AppointmentController {
	@Autowired
	private AppointmentRepository appointmentrepository;
	
	@GetMapping("/appointments")
	
	public List<Appointment> getAllAppointments()
	{
		return appointmentrepository.findAll();
		}


	@GetMapping("/appointments/{ap_id}")
	public ResponseEntity<Appointment> getAppointmentById(@PathVariable  int ap_id) throws ResourceNotFoundException {
		Appointment appointment=appointmentrepository.findById(ap_id).orElseThrow(() ->new ResourceNotFoundException("Appointment not exist with id :" +ap_id));
		return  ResponseEntity.ok(appointment);
	}
	//update doctors
	@PutMapping("/appointments/{ap_id}")
	public ResponseEntity<Appointment> updateAppointment(@PathVariable int ap_id, @RequestBody Appointment appointment) throws ResourceNotFoundException
	{
		Appointment a=appointmentrepository.findById(ap_id).orElseThrow(() ->new ResourceNotFoundException("Appointment not exist with id :" +ap_id));
		a.setD_name(appointment.getD_name());
		a.setGender(appointment.getGender());
		a.setP_name(appointment.getP_name());
		a.setAp_date(appointment.getAp_date());
		a.setAp_time(appointment.getAp_time());
		a.setAddress(appointment.getAddress());
		a.setDisease(appointment.getDisease());
		Appointment updatedAppointment = appointmentrepository.save(a);
		return ResponseEntity.ok(updatedAppointment);
	}

	
	@PostMapping("/appointments")
	public Appointment addAppointment(@RequestBody Appointment a) {
		Appointment appointment = appointmentrepository.save(a);
		return appointment;
	}



	@DeleteMapping(value = "/appointments/{ap_id}")
	public ResponseEntity< Map<String, Boolean>> deleteDoctor(@PathVariable int ap_id ) throws ResourceNotFoundException
	{
		Appointment a= appointmentrepository.findById(ap_id)
				.orElseThrow(() ->new ResourceNotFoundException("Appointment not exist with id :" +ap_id));
		appointmentrepository.delete(a);
		 Map<String, Boolean> response = new HashMap<>();
		 response.put("deleted", Boolean.TRUE);
		 return ResponseEntity.ok(response);
	}
	
}
